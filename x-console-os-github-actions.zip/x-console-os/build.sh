#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ ${EUID} -ne 0 ]]; then
  echo "Run this build inside the Debian GitHub Actions container as root." >&2
  exit 1
fi

command -v lb >/dev/null || {
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y \
    live-build debootstrap debian-archive-keyring squashfs-tools xorriso
}

mkdir -p out
rm -f ./*.iso out/*.iso out/SHA256SUMS
lb clean --purge || true

lb config \
  --architectures amd64 \
  --distribution trixie \
  --binary-images iso-hybrid \
  --bootappend-live "boot=live components quiet splash" \
  --debian-installer live \
  --debian-installer-gui true \
  --archive-areas "main contrib non-free non-free-firmware" \
  --mirror-bootstrap https://deb.debian.org/debian \
  --mirror-chroot https://deb.debian.org/debian \
  --mirror-chroot-security https://security.debian.org/debian-security \
  --mirror-binary https://deb.debian.org/debian \
  --mirror-binary-security https://security.debian.org/debian-security \
  --apt-recommends true \
  --iso-application "X-Console OS" \
  --iso-volume "XCONSOLE_OS"

lb build

iso="$(find . -maxdepth 1 -type f -name '*.iso' -print -quit)"
if [[ -z "$iso" ]]; then
  echo "Build finished but no ISO was produced." >&2
  exit 1
fi
cp -v "$iso" out/x-console-os-amd64.hybrid.iso
sha256sum out/x-console-os-amd64.hybrid.iso | tee out/SHA256SUMS
printf '\nISO created: %s\n' "$PWD/out/x-console-os-amd64.hybrid.iso"
